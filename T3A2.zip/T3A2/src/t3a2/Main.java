
package t3a2;

/**
 *
 * @author Amonet
 */
public class Main {

   
    public static void main(String[] args) {
        procesar();
      
    
    }
    public static void procesar(){
        
          
    
    
}
}
