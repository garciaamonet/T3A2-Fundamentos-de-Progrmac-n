
package t3a2;

/**
 *
 * @author Amonet
 */
public class T3A2 {
    private int horadeInicio;
    private int horaFinal;
    private String diaInicio;
    private String diaFinal;
    
    public T3A2() {}

    public T3A2(int horadeInicio, int horaFinal, String diaInicio, String diaFinal) {
        this.horadeInicio = horadeInicio;
        this.horaFinal = horaFinal;
        this.diaInicio = diaInicio;
        this.diaFinal = diaFinal;
    }

    public int getHoraInicio() {
        return horadeInicio;
    }

    public void setHoraInicio(int horadeInicio) {
        this.horadeInicio = horadeInicio;
    }

    public int getHoraFinal() {
        return horaFinal;
    }

    public void setHoraFinal(int horaFinal) {
        this.horaFinal = horaFinal;
    }

    public String getDiaInicio() {
        return diaInicio;
    }

    public void setDiaInicio(String diaInicio) {
        this.diaInicio = diaInicio;
    }

    public String getDiaFinal() {
        return diaFinal;
    }

    public void setDiaFinal(String diaFinal) {
        this.diaFinal = diaFinal;
    }

    @Override
    public String toString (){
        String mensaje = "Han transcurrido..." + "Personalizar mensaje";
        return mensaje;
    }
    }
    
                




